#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/huyang2/double-loop/official_eqr_sudoku_repro_20260623}"
REPO="${BASE}/eqr-official"
VENV="${VENV:-/huyang2/double-loop/official_eqr_compare/.venv}"
CKPT="${BASE}/downloaded_checkpoints/sudoku-extreme/eqr.pth"
LOG_DIR="${BASE}/logs"
ACTION="${1:-status}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export WANDB_MODE="${WANDB_MODE:-disabled}"
export XDG_CACHE_HOME="${BASE}/.cache"
export HF_HOME="${BASE}/.cache/huggingface"
export TORCH_EXTENSIONS_DIR="${BASE}/.cache/torch_extensions"
mkdir -p "${LOG_DIR}" "${BASE}/artifacts" "${BASE}/.cache/torch_extensions"
activate_env() {
  source "${VENV}/bin/activate"
  cd "${REPO}"
}
write_env() {
  activate_env
  {
    echo "time_utc=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "base=${BASE}"
    echo "repo=${REPO}"
    echo "repo_head=$(git rev-parse HEAD)"
    echo "repo_status_lines=$(git status --short | wc -l)"
    echo "checkpoint=${CKPT}"
    sha256sum "${CKPT}"
    sha256sum "${BASE}/artifacts/eqr-data-full.tgz"
    python -c 'import torch; print("torch", torch.__version__, "cuda", torch.cuda.is_available(), torch.cuda.get_device_name(0))'
    python -c 'from adam_atan2 import AdamATan2; import adam_atan2_backend; print("adam_atan2_backend", adam_atan2_backend.__file__)'
    python -c 'import sys; print("python", sys.version)'
  } | tee "${LOG_DIR}/env.txt"
}
apply_sdpa_fallback() {
  activate_env
  python - <<'PY'
from pathlib import Path
path = Path("models/layers.py")
text = path.read_text(encoding="utf-8")
marker = "Runtime compatibility fallback: use PyTorch SDPA"
if marker in text:
    print("sdpa fallback already present")
    raise SystemExit(0)
old = """        if q.is_cuda:\n            if flash_attn_func is None:\n                colored_exception(RuntimeError, \"flash_attn is not installed but CUDA attention was requested.\")\n            y = flash_attn_func(q=q, k=k, v=v, causal=self.causal)\n            if isinstance(y, tuple):\n                y = y[0]\n        else:\n            y = F.scaled_dot_product_attention(q.permute(0, 2, 1, 3), k.permute(0, 2, 1, 3), v.permute(0, 2, 1, 3), is_causal=self.causal).permute(0, 2, 1, 3)\n"""
new = """        if q.is_cuda and flash_attn_func is not None:\n            y = flash_attn_func(q=q, k=k, v=v, causal=self.causal)\n            if isinstance(y, tuple):\n                y = y[0]\n        else:\n            # Runtime compatibility fallback: use PyTorch SDPA when FlashAttention\n            # is unavailable or ABI-incompatible on this host.\n            y = F.scaled_dot_product_attention(q.permute(0, 2, 1, 3), k.permute(0, 2, 1, 3), v.permute(0, 2, 1, 3), is_causal=self.causal).permute(0, 2, 1, 3)\n"""
if old not in text:
    raise RuntimeError("attention block did not match pristine official source")
path.write_text(text.replace(old, new, 1), encoding="utf-8")
print("applied sdpa fallback")
PY
  git --no-pager diff > "${BASE}/artifacts/sdpa_fallback.patch"
}
run_lite() {
  write_env
  apply_sdpa_fallback
  activate_env
  local seed="${SEED:-0}"
  local suffix="sudoku_lite_D64_B128_N0.5_S1_seed${seed}"
  local log="${LOG_DIR}/eval_sudoku_lite_seed${seed}.log"
  echo "[run_lite] seed=${seed} suffix=${suffix}" | tee "${log}"
  python evaluate.py \
    eval_yaml=config/eval/sudoku_lite_noise05.yaml \
    checkpoint="${CKPT}" \
    seed="${seed}" \
    suffix="${suffix}" \
    force_rerun=true 2>&1 | tee -a "${log}"
}
case "${ACTION}" in
  status) write_env ;;
  lite) run_lite ;;
  *) echo "usage: $0 status|lite" >&2; exit 2 ;;
esac
